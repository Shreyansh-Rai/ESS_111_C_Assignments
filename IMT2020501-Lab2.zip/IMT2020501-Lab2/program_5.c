#include <stdio.h>
#include<math.h>

int main()
{
	double x,y;//cartesian coordinates
	scanf("%lf%lf",&x,&y);
	double r,th;//r is the radius and th is the angle theta
	r= sqrt( x*x + y*y);//calculation of radius
	th= atan(y/x);//calculating the theta
	printf("%.2f %.2f\n",r,th);
	return 0;	
}

