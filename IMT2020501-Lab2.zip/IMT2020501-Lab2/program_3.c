#include<stdio.h>
#include<math.h>
int main()
{
	double a,b,c;
	scanf("%lf%lf%lf",&a,&b,&c);//takes in the input for the 3 coefficients of the quadratic.
	double d= b*b - 4*a*c;
	double al,bet;//stores the alpha and beta part of the imaginary numbers if d<0 else it will store the roots of the equations 
	if(a==0)
	{
		printf("Invalid input\n");
	}
	else if(a!=0 && d<0)
	{
		al= -1*b/(2*a);//stores the real part of the root
		if(al==0) al=0;
		bet= sqrt(d*-1)/(2*a);//stores the imaginary part of the root
		printf("%.2f,%.2f\n",al,bet);
		printf("%.2f,-%.2f\n",al,bet);
	}
	else if(a!=0 &&d>=0)
	{
		al=(-1*b+sqrt(d))/(2*a); //root alpha
		bet=(-1*b-sqrt(d))/(2*a); //root beta 
		if(al>bet)
		{
			printf("%.2f\n",al);
			printf("%.2f\n",bet);
		}
		else
		{
			printf("%.2f\n",bet);
			printf("%.2f\n",al);
		}
	}
	return 0;
}
