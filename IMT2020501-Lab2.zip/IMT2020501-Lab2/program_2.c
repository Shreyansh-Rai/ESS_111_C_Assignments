#include<stdio.h>
#include<math.h>

int main()
{
	float x;
	scanf("%f",&x);
	float result= (float)(pow(x,4) - pow(x,3) - 24.0*pow(x,2) + 4*x + 80); //the biquadratic equation that is to be tested we put in the value of x evaluate and store the result in the result variable
	if(result==0)
		printf("Root\n");
	else if(result>0)
		printf("Positive\n");
	else if(result<0)
		printf("Negative\n");

	return 0;	
}
