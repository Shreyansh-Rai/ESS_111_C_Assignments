#include<stdio.h>

int main()
{
	int n,r;
	scanf("%d",&n);//n is the variable which gets the number whose sum of digits is to be calculated
	int sum=0;//calculates sum of digits
	r=0;
	while(n!=0)
	{
		r=n%10;//takes the last digit of n and stores in r
		sum+=r;//sum calculation
		n=n/10;//reduces n by 10 times 
	}
	printf("%d\n",sum);
	return 0;
}
