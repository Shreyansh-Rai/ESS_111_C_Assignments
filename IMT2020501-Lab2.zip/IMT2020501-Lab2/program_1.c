#include<stdio.h>
#include<math.h>

int main()
{
	int x,y;
	scanf("%d %d",&x,&y);
	if(x>=y)
		printf("%.2f\n",log(y));//calculates and prints ln(y)
	else
		printf("%.2f\n", exp(x));//calculates and prints e^x
	return 0;

}
