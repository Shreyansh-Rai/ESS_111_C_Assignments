#include<stdio.h>

int main()
{
	char c; int n; // c stores the class of the students and n the number of subjects he failed in
	scanf("%c%d",&c,&n);
	int g = 0; //stores the grace marks obtained by the student
	switch (c) 
	{
		case 'f' : 
			if(n<=3)
				g=n*5;
			break;
		case 's':
			if(n<=2)
				g=n*4;
			break;
		case 't':
			if(n<=1)
				g=n*5;
			break;
	}
	printf("%d\n",g);
	return 0;
}
