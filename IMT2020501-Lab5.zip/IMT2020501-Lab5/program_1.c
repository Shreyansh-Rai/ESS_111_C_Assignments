#include<stdio.h>
#include<math.h>

int main()
{
	
	int num;
	int flag=0;
	scanf("%d",&num);
	if (num<=0) //checking less than 0
		printf("Invalid input\n");
	else
	{
		for( int c=2;c<=num;c++) //iterating from 2 to num 
		{
			for(int b=ceil(sqrt(c*c/2));b<c;b++) // a<b<c => a^2<b^2 => b^2>c^2/2 so iterating from root(c^2/2) to b
			{
				int asq= c*c-b*b; //asq = a^2 
				if(sqrt(asq)==floor(sqrt(asq))) //floor(sqrt(a^2)) == root(asq) => perfect sqaure 
				{
					printf("%d %d %d\n",(int)sqrt(asq),b,c); //printing
					
					flag++;
				}
			}
			

		}
	}
	if(flag==0&&num>0)//if flag = 0 and n>0 this means the input was valid and there was no triplet found so print no triplet
		printf("No triplet\n");

	return 0;
}
