#include<stdio.h>

int main()
{
	int a,b; //input values
	int flag=0;
	scanf("%d%d",&a,&b);
	if(a<0 || b<0)//in case any one of a or b is smaller than 0 
		printf("Invalid input\n");
	
	
	else
	{
		for( int i=a;i<=b;i++)//going from a to b
		{
			int t =i;
			int arm=0; //this will store the value of the cube of digits
			while(t!=0) //calculating the sum of cube of digits of i
			{
				int r=t%10;
				arm = arm + r*r*r;
				t/=10;
			}
			if( arm==i)//checking if the arm=i and printing. flag incremented.
			{	
				printf("%d\n",i);
				flag++;
			}
			arm=0;
		}
	}
	if(flag==0 && a>=0 && b>=0)//if the value of flag is 0 and the inputs are valid 
		printf("No Armstrong Number\n");

	return 0;
}
