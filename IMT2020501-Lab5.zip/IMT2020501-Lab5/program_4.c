#include<stdio.h>

int main(){
    int n;
    char c;
    scanf("%d",&n);
    scanf(" %c",&c); //accepting the values
    
    
    if(n<=0) //for negative OR 0 n invalid case
    {
        printf("Invalid input");
    }
    else
    {   //handles the first n rows of increasing column length
        for(int i=1;i<=n;i++) //looping from 1 to n to print n rows
        {
            for(int j=1;j<=2*i-1;j++) //to print 2n-1 columns 
            {
                printf("%c ",c);
            }
            printf("\n");
        }
        //handles the next n-1 descresing columns
        for(int i=n-1;i>=1;i--)
        {
            for(int j=1;j<=2*i-1;j++)
            {
                printf("%c ",c);
            }
            printf("\n");
        }
    }
    
    return 0;
}
