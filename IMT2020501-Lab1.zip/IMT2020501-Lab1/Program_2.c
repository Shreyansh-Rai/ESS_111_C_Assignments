#include <stdio.h>

int main()
{
	        float a,b,c;//a stores the length b the width and c the radius of the circle 
	        
	        scanf("%f%f%f",&a,&b,&c);
		float arect=a*b;//area of rectangle
	        float prect=2*(a+b);//perimeter of rectangle
	        float acirc=3.14*c*c;//area of the circle
		float pcirc=2*3.14*c;//circumference of the circle
	        printf("%.2f %.2f %.2f %.2f\n",arect,prect,acirc,pcirc);								        return 0;
}
