#include <stdio.h>

int main()
{
	float tdc;// takes value of temperature in degree centigrade
	scanf("%f",&tdc);
	float tdf;//to store degree fahrenheit value
	tdf= tdc*(9/5.0)+32;//formula to convert centigrade to fahrenheit
	printf("%.2f\n",tdf);
	return 0;
}
