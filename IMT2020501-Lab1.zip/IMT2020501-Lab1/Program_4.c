#include <stdio.h>

int main()
{
	int n1,n2;// n1 and n2 are integers that will get the input value where n1 will be divided by n2
	scanf("%d%d",&n1,&n2);
	int q= n1/n2;//stores the quotient
	int r=n1%n2;//stores the remainder
	printf("%d %d\n",r,q);
	return 0;
}
