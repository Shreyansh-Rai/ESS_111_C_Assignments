#include <stdio.h>
int main()
{
	
	int n;//stores the value for which the average of squares must be calculated
	scanf("%d",&n);
	int sum= n*(n+1)*(2*n + 1)/6;//stores the sum of averages of all the values one to n
	//for( int i=1;i<=n;i++)
	//{
	//	sum += i*i; //calculation of sum of squares sum= sum+i*i
	//} alternate approach for solving
	float avg= (float)sum/(float)n;//average calculation
	printf("%.2f\n",avg);
	return 0;
}

