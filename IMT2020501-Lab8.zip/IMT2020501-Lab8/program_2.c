#include<stdio.h>
int sort(int *a,int l) //standard bubble sorting algorithm
{
    int t=0;
    for(int i=0;i<l-1;i++)
    {
        for(int j=0;j<l-i-1;j++)
        {
            if(a[j]>a[j+1]) //push the largest element to the end
            {
                t=a[j];
                a[j]=a[j+1];
                a[j+1]=t;
            }
        }
    }
    return 0;
}
int inputs(int *a,int l) //getting the inputs for the array 
{
    for(int i=0;i<l;i++)
    {
        scanf("%d",&a[i]);
    }
    return 0;
}
int Td(int *p,int l) //Just a function to display our array
{
    for(int i=0;i<l;i++)
    {
        printf("%d ",p[i]);
    }
    
    return 0;
}
int Combine(int *a1,int *a2,int l1,int l2)
{
    int c[l1+l2];//array that will store the combination of the two sorted smaller arrays
    int i1=0;int i2=0; int i=0;
    while(1)
    {
         
        if(i1==l1 && i2 == l2) //if the length of the smaller arrays is completely used then break (c is full)
        {
            break;
        }
        if(i1==l1)//if one array full only then add all the elements of the other array to c
        {
            c[i++]=a2[i2];
            i2++;
        }
        else if(i2==l2)//same as above condition but for the other array
        {
            c[i++]=a1[i1];
            i1++;
        }

        else if(a1[i1]<=a2[i2] && i1<l1 && i2<l2) //condition to put smaller elements first and then the larger ones
        {
            c[i++]=a1[i1];
            
            i1++;
        }
        else //putting smaller elements into array first
        {
            c[i++]=a2[i2];
            i2++;
      
        }
        
       
    }
    
    Td(c,l1+l2); //display the array
    return 0;
}

int main(){
    int l1;
    int l2;
    scanf("%d",&l1);
    int a1[l1];
    inputs(a1,l1);
    scanf("%d",&l2);
    int a2[l2];
    inputs(a2,l2);
    sort(a1,l1);
    sort(a2,l2);
    Combine(a1,a2,l1,l2);
    return 0;
}
