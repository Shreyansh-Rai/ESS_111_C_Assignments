#include<stdio.h>
int Push(int n,int *s,int* top)
{
    (*top)++; //increment the top first because it starts from -1
    if(*top<5) //condition for pushing
    {
        s[*top]=n;
    }
    else //Stack full condition
    {
        printf("STACK OVERFLOW\n");
        return -1;
    }
    return 0;
}
int Pop(int* s, int *top) 
{
    if((*top)==-1) //if top =-1 then then the stack has nothing in it
    {
        printf("STACK UNDERFLOW\n");
        return -1;
    }
    else
    {
        int t=s[*top]; //take the value from the top before decrementing so that appropriate value is extracted
        (*top)--;
        return t;
    }
    
}
int Display(int *s, int* top)
{
    if(*top==-1) //If the stack is empty then print
    {
        printf("STACK EMPTY\n");
    }
    else
    {
        for(int i=*top;i>=0;i--) //display the stack 
        {
            int num=Pop(s,top);
            printf("%d ",num);
        }
        printf("\n");
    }
    
}
int main(){
    char c;
    int b1,b2;
    int t=-1;
    int *top;
    top=&t;
    int s[5]; //the array based stack of size 5
    b1=0;b2=0;
    while(1) //function calls with break conditions
    {
        scanf("%c",&c);
        if(c=='a')
        {
            int tbp=0;
            scanf("%d",&tbp);
            b1=Push(tbp,s,top);
            if(b1==-1)
            break;
        }
        else if(c=='b')
        {
            b2=Pop(s,top);
            if(b2==-1)
            break;
            
        }
        else if(c=='c')
        {
            Display(s,top);
            break;
        }
    }
    return 0;
}
