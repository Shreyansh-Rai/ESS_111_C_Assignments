#include<stdio.h>

int circ(int*p,int *a,int j,int sn) //pointers to the first row of the matrix is passed
{
    for(int i=sn;i<j;i++) //the row is rotated by given amount
    *(p++)=*(a+i);
    for(int i=0;i<sn;i++)
    *(p++)=*(a++);
    return 0;
}
int main(){
    int m,n;
    scanf("%d%d",&m,&n);
    int s[m]; //array to get the shift per row
    int sn;
    int mat[m][n];//get matrix
    int ans[m][n];//get ans
    sn=0;
    for(int i=0;i<m;i++)
    {
        scanf("%d",&sn);
        s[i]=sn%n;
        for(int j=0;j<n;j++)
        {
            mat[i][j]=i+j;//stores the matrix
        }
        circ(&ans[i][0],&mat[i][0],n,s[i]); //passing the address of first element of each row of the matrices for alteration
    }
    for(int i=0;i<m;i++)
    {
        for(int j=0;j<n;j++) //print the matrix
        {
            printf("%d ",ans[i][j]); 
        }
        printf("\n");
    }
    return 0;
}
