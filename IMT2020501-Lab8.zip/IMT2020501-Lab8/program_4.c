#include<stdio.h>

int input(int *m,int l,int n)
{
    for(int i=0;i<l;i++)
    {
        for(int j=0;j<n;j++)
        {
            scanf("%d",((m+i*n)+j)); //get input
        }
    }
    return 0;
}
int display(int *m,int l,int n) //dislpay thre answer
{
    for(int i=0;i<l;i++)
    {
        for(int j=0;j<n;j++)
        {
            printf("%d ",*((m+i*n)+j));
        }
        printf("\n");
    }
    return 0;
}
int matmult(int *a1,int m1,int k,int *a2,int n2,int * ans)
{
    for(int i=0;i<m1;i++) 
    {
        for(int j=0;j<n2;j++)
        {   *((ans+i*n2)+j)=0;
            for(int l=0;l<k;l++)
            {
                *((ans+i*n2)+j)+=*((a1+i*k)+l) * *((a2+l*n2)+j);
            }
        }
    }
    return 0;
}
int main(){
    int m1,n1,m2,n2;
    scanf("%d%d%d%d",&m1,&n1,&m2,&n2);
    int ans[m1][n2];
    int a1[m1][n1];
    int a2[m2][n2];
    input((int *)a1,m1,n1);
    input((int *)a2,m2,n2);
    int k=m2;
    if(n1==m2)
    {
        matmult((int *)a1,m1,k,(int *)a2,n2,(int *)ans);
        display((int *)ans,m1,n2);
    }
    else
    {
        printf("NOT POSSIBLE");
    }
    
    return 0;
}
//logic behind matrix mult:
//so what we had to do first was initialise a result matrix that had the same number of rows as m1
//and the same number of columns as m2. the condition for multiplication is that the number of col of m1= rows of m2
//now the loop runs from 0 to p ie number of col of res and inner loop runs from 0 to q ie the number of roes of res
//now in 0,0 in res we needed the sum of products of the corresponding elements of the first row of m1 and the
//first col of m2, for 0,1 we needed the prod of the 1st row of m1 and the second col of m2 and so on
//the matrices
//so we create an innermost loop that goes from 0 to the number of columns of m1 = number of rows of m2
//now we multiply i,k of m1 with k,j if m2 and keep storing and updating the i,j of res. this is how we multiply