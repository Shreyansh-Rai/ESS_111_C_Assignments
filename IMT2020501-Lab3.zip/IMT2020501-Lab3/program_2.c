#include<stdio.h>

int main()
{
	int r,g,b; //red r green g blue b
	scanf("%d%d%d",&r,&g,&b);
	float w= (r/255.0 > g/255.0)?((r/255.0 > b/255.0)? r/255.0 : b/255.0) :((g/255.0 > b/255.0)? g/255.0 : b/255.0); 	
	float C=(w - r/255.0)/w; //determining the largest as specified above 
	float M=(w - g/255.0)/w; //CMYK nomenclature retained in the variable names
	float Y=(w - b/255.0)/w;
	float K= 1-w;
	if(r>0&&g>0&&b>0)
	printf("%.2f %.2f %.2f %.2f\n",C,M,Y,K);
	else // if all the variables r g b are 0
	{
		printf("%.2f %.2f %.2f %.2f \n",0.00,0.00,0.00,1.00);
	}
	
	return 0;
}
