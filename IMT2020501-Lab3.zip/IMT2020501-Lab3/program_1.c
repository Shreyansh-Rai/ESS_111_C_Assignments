#include <stdio.h>
#include <math.h>
#include <stdlib.h>
int main()
{
	int x1,y1,x2,y2,r1,r2; //all the values to be input
	scanf("%d%d%d%d%d%d",&x1,&y1,&r1,&x2,&y2,&r2);
	double di = sqrt( pow( abs(x1-x2),2) + pow(abs((y1-y2)),2) ); //finding out the distance between the functions
	if(r1<0 || r2<0 ) printf("Invalid Input");
	else if (r1>=0 && r2>=0 && (r1+r2)==di) printf("Touch"); // if di == r1+r2 then the circles touch 
	else if (r1>=0 && r2>=0 && (r1+r2)>di) printf("Intersect");// if di< r1+r2 then the circles intersect
	else if (r1>=0 && r2>=0 && (r1+r2)<di) printf("No Intersection"); // else there is no intersection	
}
