#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int main()
{
	int x1,y1,x2,y2,x3,y3;
	scanf("%d%d%d%d%d%d",&x1,&y1,&x2,&y2,&x3,&y3);
	double ab =sqrt( pow( (x1-x2),2) + pow((y1-y2),2) ); //calculating the length of the sides of the triangle ab bc ca 
	double bc =sqrt( pow( (x2-x3),2) + pow((y2-y3),2) );
	double ca =sqrt( pow( (x1-x3),2) + pow((y1-y3),2) );
	if((ab+bc)<=ca || (ab+ca)<=bc || (bc+ca)<=ab) 
	printf("Not Triangle");
	else
	{
		if(ab==bc&& bc==ca) //if all sides are equal
		printf("Equilateral");
		else if(ab==bc || bc==ca||ca==ab) //if any 2 sizes are equal
	    printf("Isosceles");
		else  //if not equilateral or isosceles
		printf("Scalene");
	}
	return 0;
}
