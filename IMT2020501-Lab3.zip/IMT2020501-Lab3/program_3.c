#include<stdio.h>

int main(){
    int h,t;//h is hardness t is tensile strength and c is carbon content
    float c;
    scanf("%d%f%d",&h,&c,&t);
    if(h>50 && c<0.7 && t>5600) printf("%d",10); //basic if else ladder to match and print the grade of steel
    else if(h>50 && c<0.7) printf("%d",9);
    else if(c<0.7&& t>5600) printf("%d",8);
    else if(h>50&& t>5600) printf("%d",7);
    else if(h>50 || c<0.7 || t>5600) printf("%d",6);
    else printf("%d",5);
    return 0;
}
