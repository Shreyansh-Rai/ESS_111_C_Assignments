#include<stdio.h>

int hanoi(int);

int main()
{
	int n;
	scanf("%d",&n);
	printf("%d\n",hanoi(n));
	return 0;
}

int hanoi(int x)
{
	if(x==1)
	{
		return 1; //if the hanoi of 1 is calles return 1
	}
	return (2*hanoi(x-1) + 1); //the hanoi of x = 2*hanoi(x-1)+1 as first we take the top n-1 discs,
							   //put them on the spare stand, put the larger disc on the final stand,
							   //and then finally put the n-1 discs on the largest disc this requires
							   //us to shift the top n-1 discs 2 times and the largest bottom most disc 1 time
}