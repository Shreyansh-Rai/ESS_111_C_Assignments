#include<stdio.h>
// int recApproach(int n, int id)
// {
// 	int a[]={1,2,4,8,16};
// 	for(int i=0;i<5;i++)
// 	{
// 		if(a[i
// 			]==n)
// 		{
// 			return(id);
// 		}
// 	}
// 	id==1? (id=2):(id=1);
// 	if((n-1)%3==0)
// 	{
// 		recApproach(n-1,id);
// 	}
// 	else if((n-2)%3==0)
// 	{
// 		recApproach(n-2,id);
// 	}
// 		else if (n%6==0)
// 		{
// 			recApproach(n-1,id);
// 		} 
// 		else if(n%3==0 && n%2!=0){
// 			recApproach(n-2,id);
// 		}
// }
int main()
{
	int n,id;
	scanf("%d%d",&n,&id);
	if(n%3==0)
		id==1? printf("Ravi\n"):printf("Rinku\n");
	else 
		id==1? printf("Rinku\n"):printf("Ravi\n");
	
	//	recApproach(n,id)==1 ? printf("Rinku\n"):printf("Ravi\n") ;
	return 0;
}
/*
(ALSO DONE VIA RECURSIVE APPROACH JUST IN CASE)
LOGIC:
if n=3 then the player1 will definitely lose because irrespective of what he does the opponent will always 
pick last. Now for an number of the form 3k (k>=1) the player2 can repeatedly give player1 another multiple
of 3 eg for n=9 if we chose 8 player 2 wins, if we choose 4 player 2 can chose 2 and then it is the same
as n=3 and player 2 wins similarly if we chose 2 the player 2 can chose 4 an again we have n=3 and player1 loses

but for the numbers of the form 3k-1 and 3k-2 (k>=1) the player 1 can choose 1 and 2 inorder to give the 
player2 a multiple of 3 and thus player 2 loses in all cases where n is 3k-1 and 3k-2 

*/