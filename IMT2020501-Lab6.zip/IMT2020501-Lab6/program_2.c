#include<stdio.h>

double pownum(double,int);
int fac(int);

int main()
{
	double x;
	scanf("%lf",&x);
	double ans=0.0; //to store the final answer
	int j=0;
	for(int i=1;i<=11;i+=2,j++)//loop calculating the the value of sin
	{
		ans+= pownum(-1,j)*pownum(x,i)/fac(i);
	}
	printf("%.6f\n",ans); 
	return 0;
}
double pownum(double n, int p)//pownum function returns the double n raised to p
{
	double powint=1;//powint stores the value to be returned 
	for(int i=1;i<=p;i++)
	{
		powint*=n;//repeated multiplication to find out the power
	}
    return powint;
}
int fac( int f)
{
	int facnum=1;//facnum stores the number to be returned ie, the factorial of int f
	for(int i=1;i<=f;i++)
	{
		facnum*=i;
	}
	return facnum;
}
