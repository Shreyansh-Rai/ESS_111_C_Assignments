#include<stdio.h>
#include<math.h>

double dist( double, double, double, double );
double area( double, double, double, double, double, double);

int main()
{
	double x1,y1,x2,y2,x3,y3; //input coordinates 
	scanf("%lf%lf%lf%lf%lf%lf",&x1,&y1,&x2,&y2,&x3,&y3);
	float anet=area(x1,y1,x2,y2,x3,y3); //area of the triangle formed by entered coordinates
	printf("%.6f\n",anet);
	int n; //number of inputs to take
	scanf("%d",&n);
	while(n>0)
	{
		double px,py; //point to be checked if inside the triangle
		scanf("%lf%lf",&px,&py);
		float ar1,ar2,ar3;
		ar1=area(x1,y1,x2,y2,px,py); // calculating the area of 2 sets of points and the px,py entered to check if inside.
		ar2=area(x3,y3,x2,y2,px,py);
		ar3=area(x1,y1,x3,y3,px,py);
		
		if(ar1+ar2+ar3==anet) //if the sum of the areas of all the triangles = area of the larger triangle then px,py lies in the triangle.
			printf("INSIDE\n");
		else
			printf("OUTSIDE\n");
		n--;
	}
	return 0;
}
double area ( double a1, double b1, double a2, double b2, double a3, double b3)
{
	double a= dist(a1,b1,a2,b2);
	double b= dist(a2,b2,a3,b3);
	double c= dist(a1,b1,a3,b3);
	double s= (a+b+c)/2;
	return sqrt(s*(s-a)*(s-b)*(s-c));	//area of triangle using heron's formula
}
double dist(double x1, double y1, double x2, double y2)
{
	return sqrt( (x2-x1)*(x2-x1) + (y2-y1)*(y2-y1)); //distance formula.
}
