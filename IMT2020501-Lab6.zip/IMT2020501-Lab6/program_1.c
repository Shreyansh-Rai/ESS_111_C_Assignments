#include<stdio.h>
int isPrime(int);
int main()
{
	int n; //number entered
	scanf("%d",&n);
	int tn=n;//stores n and is manipulated in calculating the prime factors.
	for(int j=2;j<=n;)
	{
		if(isPrime(j)&& tn%j==0)//if prime and j divides the number then it is a prime factor
		{
			printf("%d ",j);
			tn/=j; //updating the value of tn
		}
		else j++; //incrementing j to check if the next number is a prime factor
		if(tn==1) 
		{
			printf("\n");
			break;//breaking if tn==1 ie, all prime factors are accounted for
		}

	}
	return 0;
}
int isPrime(int ch)
{
	int f=0;
	int c=0;
	for(int i=2;i<ch;i++)
	{
		if(ch%i==0) //counts the number of factors of ch
			{
				c++;
			}
	}
	if(c==0)//if no factor but the number and 1 then the number is prime.
		f=1;

	return f;
}
