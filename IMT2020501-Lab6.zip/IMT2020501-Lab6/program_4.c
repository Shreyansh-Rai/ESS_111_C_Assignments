#include<stdio.h>
double fac(int , int );
int main()
{
    int n,r; //input the number n and r
    scanf("%d%d",&n,&r);
	int topass=0;
	if(n-r>r)
	{
		topass=r;
	}	
	else
	{
		topass=n-r;
	}
	
    double fact= fac(n,topass)/(fac(topass,topass)); //calculating n*n-1*n-2....n-topass+1/r! where topass is either r or n-r which ever is
                                                   //more efficient
    printf("%0.0lf\n",fact); // priting the value as a double without the decimal points for better precesion of values
    return 0;
}

double fac(int n, int r)
{
    double f=1;
    for(int i=n;i>n-r;i--) //calculating the product from n to n-r+1
    {
        f=f*i;
    }
    return f;
}

