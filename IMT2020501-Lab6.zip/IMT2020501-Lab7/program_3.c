#include<stdio.h>

int gcd(int,int);

int main() 
{
	int n1,n2;
	scanf("%d%d",&n1,&n2);
	printf("%d\n",gcd(n1,n2));
	return 0;
}

int gcd(int b,int a) //since gcd(b,a) = gcd(a,b%a) we recursively call gcd(a,b%a)
{ 
	if(b%a==1) //if the b%a becomes 1 we must return gcd as 1 beecause in the next iteration a%1 will be true
	{		   //so we can save on one call and directly return 1
		return 1;
	}	
	else if(a%(b%a)==0) //if a is divisible by b%a then b%a is the GCD
	{
		return (b%a);
	}
	else //recursive call to the function incase the gcd is not found.
	{
		gcd(a,b%a);
	}

}