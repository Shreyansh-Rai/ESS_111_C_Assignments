#include<stdio.h>

int is_palindrome(int);
int rev; //stores the reverse of teh number
int temp;//sroes the number
int main()
{
	int num;
	rev=0;
	scanf("%d",&num);
	temp=num; 
	if(is_palindrome(num)) //if is palindrome returns 1 then it is palindrome else not
	{
		printf("Yes\n");
	}
	else 
	{
		printf("No\n");
	}
	return 0;
}

int is_palindrome(int x)
{
	rev=rev*10 + x%10; //calculating the reverse of the number on every call
	if(rev==temp) //if the reverse of the number and the number input match then they are palindrome and we return 1 
	{
		return 1;
	}
	else if(x==0) //else if x becomes 0 and we have never gotten the first if correct then we return 0
	{
		return 0;
	}
	is_palindrome(x/10); //calling n/10 each time so that we can continue to store the reverse
}