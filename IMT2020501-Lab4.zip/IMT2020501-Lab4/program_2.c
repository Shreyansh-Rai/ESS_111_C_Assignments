#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	if(n<0) //if nember is less than 0 prints inavlid input
	{
		printf("Invalid input\n");
	}
	else
	{
		int r=0;
		int rev=0;//stores the reversed number
		while(n!=0)//runs the loops till the number becomes 0
		{
			r= n%10;//extracting the last digit
		        rev=rev*10 + r;//reversing numeber by multiplying the rev by 10 each time and adding r to rev
			n/=10;//reduces the number by 10 times to make a new last digit available to extract
		}
		printf("%d\n",rev); //prints the reversed numbers

	}
	return 0;
}
