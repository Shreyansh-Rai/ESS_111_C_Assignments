#include<stdio.h>
#include<stdlib.h>
int main()
{
 	int max, min;//stores the maximum and minimum numbers respectively 
	int range;//stores max-min
	max=0;min=0;
	int l=0;//length of the input the user will give
	scanf("%d",&l);
	if(l<=0)
	{
		printf("Invalid input\n");
		exit(0);
	}
	int n=0;
	
	scanf("%d",&n);
	max=n;//initialising the max and min with the first input and values will be compared and updated in loop
	min=n;
	for(int i=0;i<l-1;i++)
	{
		scanf("%d",&n);
		if(max<n) {max=n;}//if the num is greater than max then make max= number 
			
		if(min>n) {min=n;}//if min is greater than the num then make min= number
			

	}
	range = 0;
	range=max-min;//calculating the range
	printf("%d\n",range);
	return 0;
}
