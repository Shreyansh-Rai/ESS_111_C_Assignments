#include <stdio.h>
int main()
{
	int n;
 	scanf("%d",&n);
	if(n<0)//invalid input for any value less than 0
	{
 		printf("Invalid input\n");

	}
	else
	{
		 int r=0;//stores the remainder when n is divided by 8 
		 int p=1;//stores the place in decimal notation at which  r must be present
		 int oc=0;//stores the final octal number
		 while(n!=0)
		 {
			r=n%8;//getting the remainder
			oc=oc + p*r;//setting octal = remainder but the place value is getting increased by 10 every time so that
			// the first remainder will be eventually at the first position in oc
			n/=8;
			p*=10;

		 }
		 printf("%d\n",oc);

	}
	return 0;
}
