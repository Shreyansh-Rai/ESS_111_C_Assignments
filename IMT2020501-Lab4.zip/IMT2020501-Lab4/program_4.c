#include<stdio.h>
int main()
{
	int n;//number that will be checked for the gcd
	scanf("%d",&n);
	if(n<=0)
	{
		printf("Invalid input\n");
	}
	else
	{
		int k=0;int count=0; //k stores the number of common divisors of any 'i' and n count stores the total
		//number of natural numbers that have only 1 as common factor with the numeber n.
		for(int i=1;i<=n;i++)//loop from 1 to less than as specified 
		{
			k=0;//flushing the vallue of k before going into the interior loop 
			for( int j=1; j<=i;j++)
			{
				if(n%j==0 && i%j==0)//if the i and n have a common factor j then k = k+1
				{
					k++;//stores the number of common factors of i and n
				}
			}
			if(k==1)// if there is only one common factor that means the common factor was 1 and they are 
				//coprime numbers with gcd 1
			{
				count++;//counts the number of such values of i for which i,n are co primes
			}

		}
		if(n==1) printf("1\n"); // the case in which n=1 is handled over here. if n= 1 1 and itself are 
					// coprime and so 1 is displayed

		else printf("%d\n",count);// in any other case the count is displayed
		
		

	}
	return 0;
}
